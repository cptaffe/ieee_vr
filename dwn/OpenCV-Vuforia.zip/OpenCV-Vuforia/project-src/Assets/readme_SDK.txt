Vuforia Augmented Reality SDK Release Package
==============================================

It is recommended that use of the Unity Extensions for Vuforia be employed with the 
4.5.x version (or later) of the Unity Editor and Runtime.

To get started, go to https://developer.vuforia.com, where you will find detailed 
documentation on developing AR apps using the Vuforia SDK, and a brief description 
of the online Target Manager.

To view the SDK license agreement, go to https://developer.vuforia.com/legal/vuforia-developer-agreement

To view the release notes, go to https://developer.vuforia.com/library/release-notes


/*============================================================================
            Copyright (c) 2010-2015 Qualcomm Connected Experiences, Inc.
            All Rights Reserved.
         Confidential and Proprietary - Qualcomm Connected Experiences, Inc.
  ============================================================================*/
