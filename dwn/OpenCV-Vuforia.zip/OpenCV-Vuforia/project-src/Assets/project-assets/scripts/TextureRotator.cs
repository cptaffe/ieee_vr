using UnityEngine;
using System.Collections;

public class TextureRotator : MonoBehaviour
{

    public GameObject target;
    public Material[] materialList;
    public int currentMaterial = 0;
    
    OpenCvHandDetection cvHandDetectionFist;
    OpenCvHandDetection cvHandOpenPalm;
    OpenCvVideoCaptureManager cvVideoCapture;

    void Start()
    {
        cvVideoCapture = new OpenCvVideoCaptureManager();
        cvHandDetectionFist = new OpenCvHandDetection();
        cvHandOpenPalm = new OpenCvHandDetection(OpenCvHandDetection.palm);
        target.renderer.material = materialList[currentMaterial];
    }

    void Update()
    {
        var curBuffer = cvVideoCapture.ReadAndGetCurrentBuffer();
        cvHandOpenPalm.HandDetection(curBuffer);
        cvHandDetectionFist.HandDetection(curBuffer);
        if (cvHandOpenPalm.HandPresent)
        {
            nextMaterial();
        }
    }

    void nextMaterial()
    {
        currentMaterial++;
        target.renderer.material = materialList[currentMaterial % materialList.Length];
    }
}