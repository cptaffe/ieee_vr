/*============================================================================
Copyright (c) 2014 Qualcomm Connected Experiences, Inc.
All Rights Reserved.
============================================================================*/
 

#import "PluginBase/RenderPluginDelegate.h"

// Controller to support native rendering callback
@interface VuforiaRenderDelegate : NSObject<RenderPluginDelegate>
@end